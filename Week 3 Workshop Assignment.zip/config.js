module.exports = {
    secretKey: "12345-67890-09876-54321",
    mongoUrl: "mongodb://0.0.0.0:27017/nucampsite",
};
